The code in this folder is stuff that I've worked on or am working on.

I don't guarantee functionality for this code.

You've been warned.

-Ed